library(tidyverse)
library(ggplot2)
library(ggrepel)
library(dplyr)
library(readxl)
library(purrr)
library(tidyr)

#caricamento file AV4

av4_volcano <- read_excel("AV4 volcano plot.xlsx")

#confronto tra R1032Q e R1032Q siRNA SCL1A5

av4_volcano_1032_1032sirna <- av4_volcano |>
  select(metabolite, Fold_change_R1032Qsirna_vs_R1032Q, Pvalue_R1032Q_vs_R1032Q_sirna)

pvalue_threshold <- -log10(0.05)
fc_separator <- 0
biological_significance <- 0.2

av4_volcano_1032_1032sirna <- av4_volcano_1032_1032sirna  |>
  mutate(
    Significance = case_when(
      Fold_change_R1032Qsirna_vs_R1032Q > biological_significance & Pvalue_R1032Q_vs_R1032Q_sirna > pvalue_threshold ~ "Up-regulated",
      Fold_change_R1032Qsirna_vs_R1032Q < -biological_significance & Pvalue_R1032Q_vs_R1032Q_sirna > pvalue_threshold ~ "Down-regulated",
      TRUE ~ "Not Significant"
    )
  )

av4_volcano_1032_1032sirna|> 
  ggplot(aes(x = Fold_change_R1032Qsirna_vs_R1032Q, y = Pvalue_R1032Q_vs_R1032Q_sirna, color = Significance)) +
  geom_point(alpha = 0.8, size = 2.5) +
  scale_color_manual(values = c("Up-regulated" = "firebrick", 
                                "Down-regulated" = "steelblue", 
                                "Not Significant" = "grey75")) +
  geom_vline(xintercept = c(biological_significance,  -biological_significance),col = "black", linetype = "dashed", alpha = 0.5 ) +
  geom_hline(yintercept = pvalue_threshold, col = "black", linetype = "dashed", alpha = 0.5) +
  geom_text_repel(
    data = subset(av4_volcano_1032_1032sirna, Significance != "Not Significant"),
    aes(label = metabolite),
    size = 3.5,
    max.overlaps = Inf,          
    show.legend = FALSE,
    color = "black"
  ) +
  theme_classic() +
  labs(
    title = "Volcano Plot of Metabolites",
    subtitle = "VEGFR2 R1032Q vs VEGFR2 R1032Q siRNA SLC1A5",
    x = bquote(~Log[2]~ "FC"),
    y = bquote(~-Log[10]~ "(P-value)")
  ) +
  theme(
    plot.title = element_text(face = "bold", size = 16, hjust = 0.5),
    plot.subtitle = element_text(size = 12, hjust = 0.5),
    axis.title = element_text(face = "bold", size = 12),
    legend.position = "right",
    legend.title = element_blank(),
    legend.text = element_text(size = 10)
  )

#confronto tra Wt e wt siRNA SCL1A5

av4_volcano_WT_WTsirna <- av4_volcano |>
  select(metabolite, Fold_change_Wtsirna_WT, Pvalue_WT_vs_sirna)

pvalue_threshold <- -log10(0.05)
fc_separator <- 0
biological_significance <- 0.2

av4_volcano_WT_WTsirna <- av4_volcano_WT_WTsirna  |>
  mutate(
    Significance = case_when(
      Fold_change_Wtsirna_WT > biological_significance & Pvalue_WT_vs_sirna > pvalue_threshold ~ "Up-regulated",
      Fold_change_Wtsirna_WT < -biological_significance & Pvalue_WT_vs_sirna > pvalue_threshold ~ "Down-regulated",
      TRUE ~ "Not Significant"
    )
  )

av4_volcano_WT_WTsirna|> 
  ggplot(aes(x = Fold_change_Wtsirna_WT, y = Pvalue_WT_vs_sirna, color = Significance)) +
  geom_point(alpha = 0.8, size = 2.5) +
  scale_color_manual(values = c("Up-regulated" = "firebrick", 
                                "Down-regulated" = "steelblue", 
                                "Not Significant" = "grey75")) +
  geom_vline(xintercept = c(biological_significance,  -biological_significance),col = "black", linetype = "dashed", alpha = 0.5 ) +
  geom_hline(yintercept = pvalue_threshold, col = "black", linetype = "dashed", alpha = 0.5) +
  geom_text_repel(
    data = subset(av4_volcano_WT_WTsirna, Significance != "Not Significant"),
    aes(label = metabolite),
    size = 3.5,
    max.overlaps = Inf,          
    show.legend = FALSE,
    color = "black"
  ) +
  theme_classic() +
  labs(
    title = "Volcano Plot of Metabolites",
    subtitle = "VEGFR2 WT vs VEGFR2 WT siRNA SLC1A5",
    x = bquote(~Log[2]~ "FC"),
    y = bquote(~-Log[10]~ "(P-value)")
  ) +
  theme(
    plot.title = element_text(face = "bold", size = 16, hjust = 0.5),
    plot.subtitle = element_text(size = 12, hjust = 0.5),
    axis.title = element_text(face = "bold", size = 12),
    legend.position = "right",
    legend.title = element_blank(),
    legend.text = element_text(size = 10)
  )
#wt vs R1032Q sirna
AV4_volcano_R1032Qsh_WT <- read_xlsx("AV4_VP_R1032Q_SH_VS_WT.xlsx")
AV4_volcano_R1032Qsh_WT <- AV4_volcano_R1032Qsh_WT |>
  select(-P_value) 
  
  AV4_volcano_R1032Qsh_WT <- AV4_volcano_R1032Qsh_WT |>
  mutate(
    Significance = case_when(
      Fold_change_log2_R1032QsHvsWT > biological_significance & pvalue_logscale_R1032QsHvsWT > pvalue_threshold ~ "Up-regulated",
      Fold_change_log2_R1032QsHvsWT < -biological_significance & pvalue_logscale_R1032QsHvsWT > pvalue_threshold ~ "Down-regulated",
      TRUE ~ "Not Significant"
    )
  )



AV4_volcano_R1032Qsh_WT |> 
  ggplot(aes(x = Fold_change_log2_R1032QsHvsWT, y = pvalue_logscale_R1032QsHvsWT, color = Significance)) +
  geom_point(alpha = 0.8, size = 2.5) +
  scale_color_manual(values = c("Up-regulated" = "firebrick", 
                                "Down-regulated" = "steelblue", 
                                "Not Significant" = "grey75")) +
  geom_vline(xintercept = c(biological_significance,  -biological_significance),col = "black", linetype = "dashed", alpha = 0.5 ) +
  geom_hline(yintercept = pvalue_threshold, col = "black", linetype = "dashed", alpha = 0.5) +
  geom_text_repel(
    data = subset(AV4_volcano_R1032Qsh_WT, Significance != "Not Significant"),
    aes(label = metabolite),
    size = 3.5,
    max.overlaps = Inf,          
    show.legend = FALSE,
    color = "black"
  ) +
  theme_classic() +
  labs(
    title = "Volcano Plot of Metabolites",
    subtitle = "VEGFR2 WT vs VEGFR2 R1032Q siRNA SLC1A5",
    x = bquote(~Log[2]~ "FC"),
    y = bquote(~-Log[10]~ "(P-value)")
  ) +
  theme(
    plot.title = element_text(face = "bold", size = 16, hjust = 0.5),
    plot.subtitle = element_text(size = 12, hjust = 0.5),
    axis.title = element_text(face = "bold", size = 12),
    legend.position = "right",
    legend.title = element_blank(),
    legend.text = element_text(size = 10)
  )
  











#diagrammi a barre


#upregulated



AV4_VOLCANO_BP_WT_sirna <- av4_volcano_WT_WTsirna |>
  filter(Significance == "Up-regulated" | metabolite == "Aspartate") |>
  select(-Significance)

AV4_VOLCANO_BP_1032_sirna <- av4_volcano_1032_1032sirna |>
  filter(Significance == "Up-regulated") |>
  select(-Significance)

AV4_volcano_BP_R1032Qsh_WT <- AV4_volcano_R1032Qsh_WT |>
  filter(Significance == "Up-regulated" | metabolite == "Aspartate" | metabolite ==  "Lysine") |>
  select(-Significance)


AV4_VOLCANO_BP <- inner_join(AV4_VOLCANO_BP_1032_sirna, AV4_VOLCANO_BP_WT_sirna) 
AV4_VOLCANO_BP <- inner_join(AV4_VOLCANO_BP, AV4_volcano_BP_R1032Qsh_WT)

                               

AV4_VOLCANO_long <- AV4_VOLCANO_BP |>
  pivot_longer(
    cols = -metabolite, 
    names_to = "Variable", 
    values_to = "Value"
  ) |>
    mutate(
      Metric = ifelse(grepl("Fold_change", Variable, ignore.case = TRUE), "Fold_Change", "P_Value"),
      Condition = case_when(
        grepl("R1032QsH", Variable, ignore.case = TRUE) ~ "WT vs R1032Q siRNA",
        grepl("R1032Q", Variable, ignore.case = TRUE) ~ "R1032Q vs R1032Q siRNA",
        grepl("WT", Variable, ignore.case = TRUE) ~ "WT vs WT siRNA",
        TRUE ~ "Unknown" 
      )
    )|>
  select(metabolite, Condition, Metric, Value)


view(AV4_VOLCANO_long)


AV4_FC_data <- AV4_VOLCANO_long |> filter(Metric == "Fold_Change")
AV4_P_data <- AV4_VOLCANO_long |> filter(Metric == "P_Value")



AV4_FC_data |>  
  ggplot(aes(x = reorder(metabolite, -Value), y = Value, fill = Condition)) +
  geom_bar(stat = "identity", position = position_dodge(width = 0.8), width = 0.7, color = "black") +
  scale_fill_manual(values = c("WT vs WT siRNA" = "red", 
                               "R1032Q vs R1032Q siRNA" = "blue", 
                               "WT vs R1032Q siRNA" = "green")) +
  geom_hline(yintercept = 0.2, linetype = "dashed", color = "black", alpha = 0.5) +
  theme_classic() +
  labs(
    title = "Up-regulated Metabolites: Fold Change",
    x = "Metabolite",
    y = bquote(~Log[2]~ "Fold Change")
  ) +
  theme(
    axis.text.x = element_text(angle = 45, hjust = 1, face = "bold"),
    legend.position = "top",
    legend.title = element_blank()
  )



AV4_P_data |> 
  ggplot(aes(x = reorder(metabolite, -Value), y = Value, fill = Condition)) +
  geom_bar(stat = "identity", position = position_dodge(width = 0.8), width = 0.7, color = "black") +
  geom_hline(yintercept = -log10(0.05), linetype = "dashed", color = "black", alpha = 0.5) + 
  scale_fill_manual(values = c("WT vs WT siRNA" = "red", 
                               "R1032Q vs R1032Q siRNA" = "blue", 
                               "WT vs R1032Q siRNA" = "green")) +
  theme_classic() +
  labs(
    title = "Up-regulated Metabolites: Significance",
    x = "Metabolite",
    y = bquote(~-Log[10]~ "(P-value)")
  ) +
  theme(
    axis.text.x = element_text(angle = 45, hjust = 1, face = "bold"),
    legend.position = "top",
    legend.title = element_blank()
  )

#downregulated

AV4_VOLCANO_BP1_WT_sirna <- av4_volcano_WT_WTsirna |>
  filter(Significance == "Down-regulated" | metabolite == "Proline") |>
  select(-Significance)

AV4_VOLCANO_BP1_1032_sirna <- av4_volcano_1032_1032sirna |>
  filter(Significance == "Down-regulated") |>
  select(-Significance)

AV4_volcano_BP1_R1032Qsh_WT <- AV4_volcano_R1032Qsh_WT |>
  filter(Significance == "Down-regulated" | metabolite == "Proline") |>
  select(-Significance)

AV4_VOLCANO_BP1 <- inner_join(AV4_VOLCANO_BP1_1032_sirna, AV4_VOLCANO_BP1_WT_sirna) 
AV4_VOLCANO_BP1 <- inner_join(AV4_VOLCANO_BP1, AV4_volcano_BP1_R1032Qsh_WT) 
AV4_VOLCANO_long1 <- AV4_VOLCANO_BP1 |>
  pivot_longer(
    cols = -metabolite, 
    names_to = "Variable", 
    values_to = "Value"
  ) |>
  mutate(
    Metric = ifelse(grepl("Fold_change", Variable, ignore.case = TRUE), "Fold_Change", "P_Value"),
    Condition = case_when(
      grepl("R1032QsH", Variable, ignore.case = TRUE) ~ "WT vs R1032Q siRNA",
      grepl("R1032Q", Variable, ignore.case = TRUE) ~ "R1032Q vs R1032Q siRNA",
      grepl("WT", Variable, ignore.case = TRUE) ~ "WT vs WT siRNA",
      TRUE ~ "Unknown" 
    )
  )|>
  select(metabolite, Condition, Metric, Value) 

AV4_FC_data1 <- AV4_VOLCANO_long1 |> filter(Metric == "Fold_Change")
AV4_P_data1 <- AV4_VOLCANO_long1 |> filter(Metric == "P_Value")

AV4_P_data1 |> 
  ggplot(aes(x = reorder(metabolite, -Value), y = Value, fill = Condition)) +
  geom_bar(stat = "identity", position = position_dodge(width = 0.8), width = 0.7, color = "black") +
  geom_hline(yintercept = -log10(0.05), linetype = "dashed", color = "black", alpha = 0.5) + 
  scale_fill_manual(values = c("WT vs WT siRNA" = "red", 
                               "R1032Q vs R1032Q siRNA" = "blue", 
                               "WT vs R1032Q siRNA" = "green")) +
  theme_classic() +
  labs(
    title = "Down-regulated Metabolites: Significance",
    x = "Metabolite",
    y = bquote(~-Log[10]~ "(P-value)")
  ) +
  theme(
    axis.text.x = element_text(angle = 45, hjust = 1, face = "bold"),
    legend.position = "top",
    legend.title = element_blank()
  ) 

AV4_FC_data1 |>  
  ggplot(aes(x = reorder(metabolite, -Value), y = Value, fill = Condition)) +
  geom_bar(stat = "identity", position = position_dodge(width = 0.8), width = 0.7, color = "black") +
  scale_fill_manual(values = c("WT vs WT siRNA" = "red", 
                               "R1032Q vs R1032Q siRNA" = "blue", 
                               "WT vs R1032Q siRNA" = "green")) +
  geom_hline(yintercept = -0.2, linetype = "dashed", color = "black", alpha = 0.5) +
  theme_classic() +
  labs(
    title = "Down-regulated Metabolites: Fold Change",
    x = "Metabolite",
    y = bquote(~Log[2]~ "Fold Change")
  ) +
  theme(
    axis.text.x = element_text(angle = 45, hjust = 1, face = "bold"),
    legend.position = "top",
    legend.title = element_blank()
  )
