library(tidyverse)
library(ggplot2)
library(ggrepel)
library(dplyr)
library(readxl)
library(purrr)
library(tidyr)


AV4_VOLCANO_long1 <- amino_acids <- read_excel("amino_acids.xlsx")



AV4_FC_data1 <- AV4_VOLCANO_long1 |> filter(Metric == "Fold_Change")
AV4_P_data1 <- AV4_VOLCANO_long1 |> filter(Metric == "P_Value")

AV4_P_data1 |> 
  ggplot(aes(x = reorder(metabolite, -Value), y = Value, fill = Condition)) +
  geom_bar(stat = "identity", position = position_dodge(width = 0.8), width = 0.7, color = "black") +
  geom_hline(yintercept = -log10(0.05), linetype = "dashed", color = "black", alpha = 0.5) + 
  scale_fill_manual(values = c("WT vs WT siRNA" = "red", 
                               "R1032Q vs R1032Q siRNA" = "blue", 
                               "WT vs R1032Q siRNA" = "green",
                               "WT vs R1032Q" = "orange")) +
  theme_classic() +
  labs(
    title = "Up-regulated Metabolites: Significance",
    x = "Metabolite",
    y = bquote(~-Log[10]~ "(P-value)")
  ) +
  theme(
    axis.text.x = element_text(angle = 45, hjust = 1, face = "bold"),
    legend.position = "top",
    legend.title = element_blank()
  ) 

AV4_FC_data1 |>  
  ggplot(aes(x = reorder(metabolite, -Value), y = Value, fill = Condition)) +
  geom_bar(stat = "identity", position = position_dodge(width = 0.8), width = 0.7, color = "black") +
  scale_fill_manual(values = c("WT vs WT siRNA" = "red", 
                               "R1032Q vs R1032Q siRNA" = "blue", 
                               "WT vs R1032Q siRNA" = "green",
                               "WT vs R1032Q" = "orange")) +
  geom_hline(yintercept = c(0.2,-0.2), linetype = "dashed", color = "black", alpha = 0.5) +
  theme_classic() +
  labs(
    title = "Up-regulated Metabolites: Fold Change",
    x = "Metabolite",
    y = bquote(~Log[2]~ "Fold Change")
  ) +
  theme(
    axis.text.x = element_text(angle = 45, hjust = 1, face = "bold"),
    legend.position = "top",
    legend.title = element_blank()
  )



AV4_VOLCANO_long <- read_excel("glucose_derivates2.xlsx")

AV4_FC_data <- AV4_VOLCANO_long |> filter(Metric == "Fold_Change")
AV4_P_data <- AV4_VOLCANO_long |> filter(Metric == "P_Value")



AV4_FC_data |>  
  ggplot(aes(x = reorder(metabolite, -Value), y = Value, fill = Condition)) +
  geom_bar(stat = "identity", position = position_dodge(width = 0.8), width = 0.7, color = "black") +
  scale_fill_manual(values = c("WT vs WT siRNA" = "red", 
                               "R1032Q vs R1032Q siRNA" = "blue", 
                               "WT vs R1032Q siRNA" = "green",
                               "WT vs R1032Q" = "orange")) +
  geom_hline(yintercept = c(0.2, -0.2), linetype = "dashed", color = "black", alpha = 0.5) +
  theme_classic() +
  labs(
    title = "Down-regulated Metabolites: Fold Change",
    x = "Metabolite",
    y = bquote(~Log[2]~ "Fold Change")
  ) +
  theme(
    axis.text.x = element_text(angle = 45, hjust = 1, face = "bold"),
    legend.position = "top",
    legend.title = element_blank()
  )



AV4_P_data |> 
  ggplot(aes(x = reorder(metabolite, -Value), y = Value, fill = Condition)) +
  geom_bar(stat = "identity", position = position_dodge(width = 0.8), width = 0.7, color = "black") +
  geom_hline(yintercept = -log10(0.05), linetype = "dashed", color = "black", alpha = 0.5) + 
  scale_fill_manual(values = c("WT vs WT siRNA" = "red", 
                               "R1032Q vs R1032Q siRNA" = "blue", 
                               "WT vs R1032Q siRNA" = "green",
                               "WT vs R1032Q" = "orange")) +
  theme_classic() +
  labs(
    title = "Down-regulated Metabolites: Significance",
    x = "Metabolite",
    y = bquote(~-Log[10]~ "(P-value)")
  ) +
  theme(
    axis.text.x = element_text(angle = 45, hjust = 1, face = "bold"),
    legend.position = "top",
    legend.title = element_blank()
  )