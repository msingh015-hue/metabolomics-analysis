library(tidyverse)
library(ggplot2)
library(dplyr)
library(readxl)
library(tidydr)

intracellular_data <- read_excel("AV4 PCA.xlsx")
intracellular_long <- pivot_longer(intracellular_data, 
                        cols = -Condition, 
                        names_to = "Metabolite", 
                        values_to = "Concentration")



p <- intracellular_long |>
  ggplot(aes(x = Condition, y = Concentration, fill = Condition)) +
  geom_boxplot(outlier.size = 1) + 
  facet_wrap(~ Metabolite, scales = "free_y", ncol = 5) + 
  theme_bw() + 
  theme(
    axis.text.x = element_blank(), 
    axis.ticks.x = element_blank(),
    strip.text = element_text(size = 9, face = "bold"), 
    legend.position = "bottom",
    legend.title = element_blank()
  ) +
  labs(title = "Intracellular Metabolite Levels by Condition",
       x = NULL, 
       y = "Relative Abundance")
print(p)
