library(corrr)
library(ggcorrplot)
library(FactoMineR)
library(factoextra)
library(readxl)
library(tidyverse)
library(ggrepel)
library(dplyr) 
library(plotly)

#caricamento file AV4 PCA

slc1a5_data <- read_excel("AV4 PCA.xlsx")

#Wtsirna vs 1032sirna

WTsirna_1032sirna <- slc1a5_data |>
  slice(4:6, 10:12)
numerical_data <- WTsirna_1032sirna[,2:23]
numerical_data <- scale(numerical_data)

corr_matrix <- cor(numerical_data)
ggcorrplot(corr_matrix, 
           hc.order = TRUE,
           type = "lower")

data.pca <- prcomp(numerical_data)
summary(data.pca) 


fviz_eig(data.pca, addlabels = TRUE)
data.pca$rotation[, 1:3]
fviz_pca_var(data.pca, 
             geom = c("point", "text"),
             col.var = "black",
             repel = TRUE) +
  theme_classic()

fviz_cos2(data.pca, choice = "var", axes = 1:2)

sample_groups <- WTsirna_1032sirna[[1]]

pca_3d_data <- data.frame(
  PC1 = data.pca$x[, 1],
  PC2 = data.pca$x[, 2],
  PC3 = data.pca$x[, 3],
  Group = sample_groups
) 

groups <- unique(pca_3d_data$Group)
group_colors <- c("red", "blue")

#dynamic 3D plot 
var_explained <- data.pca$sdev^2 / sum(data.pca$sdev^2)
pc1_lab <- paste0("PC1 (", round(var_explained[1] * 100, 1), "%)")
pc2_lab <- paste0("PC2 (", round(var_explained[2] * 100, 1), "%)")
pc3_lab <- paste0("PC3 (", round(var_explained[3] * 100, 1), "%)") 


 fig <- plot_ly(data = pca_3d_data, 
               x = ~PC1, 
               y = ~PC2, 
               z = ~PC3, 
               color = ~Group, 
               colors = group_colors,
               type = "scatter3d", 
               mode = "markers",
               marker = list(
                 size = 10,                 
                 opacity = 0.9,            
                 line = list(               
                   color = "black",
                   width = 2
                 )
               )) |>
  layout(
    title = list(
      text = "<b>3D PCA</b><br><sup>VEGFR2 WT siRNA SLC1A5 Vs VEGFR2 R1032Q siRNA SLC1A5</sup>",
      font = list(family = "Helvetica", size = 18, color = "#333333"),
      x = 0.05 
    ),
    scene = list(
      xaxis = list(title = pc1_lab, 
                   backgroundcolor = "#F4F6F9", 
                   gridcolor = "white", 
                   showbackground = TRUE, 
                   zerolinecolor = "white",
                   tickfont = list(color = "#555555")),
      yaxis = list(title = pc2_lab, 
                   backgroundcolor = "#F4F6F9", 
                   gridcolor = "white", 
                   showbackground = TRUE, 
                   zerolinecolor = "white",
                   tickfont = list(color = "#555555")),
      zaxis = list(title = pc3_lab, 
                   backgroundcolor = "#F4F6F9", 
                   gridcolor = "white", 
                   showbackground = TRUE, 
                   zerolinecolor = "white",
                   tickfont = list(color = "#555555")),
      camera = list(eye = list(x = 1.5, y = 1.5, z = 1.2)) 
    ),
    paper_bgcolor = "white", 
    plot_bgcolor = "white",
    legend = list(
      title = NULL,
      orientation = "h",  
      x = 0.5,            
      y = -0.1,            
      xanchor = "center",
      font = list(size = 12)
    ),
    margin = list(l = 0, r = 0, b = 50, t = 80) 
  ) 
 
 
 #1032 vs 1032 sirna
 
 R1032Q_1032sirna <- slc1a5_data |>
   slice(7:12)
 numerical_data2 <-  R1032Q_1032sirna[,2:23]
 numerical_data2 <- scale(numerical_data2)
 
 corr_matrix2 <- cor(numerical_data2)
 ggcorrplot(corr_matrix2, 
            hc.order = TRUE,
            type = "lower")
 
 data.pca2 <- prcomp(numerical_data2)
 summary(data.pca2) 
 
 
 fviz_eig(data.pca2, addlabels = TRUE)
 data.pca2$rotation[, 1:3]
 fviz_pca_var(data.pca2, 
              geom = c("point", "text"),
              col.var = "black",
              repel = TRUE) +
   theme_classic()
 
 fviz_cos2(data.pca2, choice = "var", axes = 1:2)
 
sample_groups2 <- R1032Q_1032sirna[[1]]
 
 pca_3d_data2 <- data.frame(
   PC1 = data.pca2$x[, 1],
   PC2 = data.pca2$x[, 2],
   PC3 = data.pca2$x[, 3],
   Group = sample_groups2
 ) 
 
 groups2 <- unique(pca_3d_data2$Group)
 group_colors <- c("red", "blue")
 
 #dynamic 3D plot 
 var_explained2 <- data.pca2$sdev^2 / sum(data.pca2$sdev^2)
 pc1_lab2 <- paste0("PC1 (", round(var_explained2[1] * 100, 1), "%)")
 pc2_lab2 <- paste0("PC2 (", round(var_explained2[2] * 100, 1), "%)")
 pc3_lab2 <- paste0("PC3 (", round(var_explained2[3] * 100, 1), "%)") 
 
 
 fig2 <- plot_ly(data = pca_3d_data2, 
                x = ~PC1, 
                y = ~PC2, 
                z = ~PC3, 
                color = ~Group, 
                colors = group_colors,
                type = "scatter3d", 
                mode = "markers",
                marker = list(
                  size = 10,                 
                  opacity = 0.9,            
                  line = list(               
                    color = "black",
                    width = 2
                  )
                )) |>
   layout(
     title = list(
       text = "<b>3D PCA</b><br><sup>VEGFR2 R1032Q Vs VEGFR2 R1032Q siRNA SLC1A5</sup>",
       font = list(family = "Helvetica", size = 18, color = "#333333"),
       x = 0.05 
     ),
     scene = list(
       xaxis = list(title = pc1_lab2, 
                    backgroundcolor = "#F4F6F9", 
                    gridcolor = "white", 
                    showbackground = TRUE, 
                    zerolinecolor = "white",
                    tickfont = list(color = "#555555")),
       yaxis = list(title = pc2_lab2, 
                    backgroundcolor = "#F4F6F9", 
                    gridcolor = "white", 
                    showbackground = TRUE, 
                    zerolinecolor = "white",
                    tickfont = list(color = "#555555")),
       zaxis = list(title = pc3_lab2, 
                    backgroundcolor = "#F4F6F9", 
                    gridcolor = "white", 
                    showbackground = TRUE, 
                    zerolinecolor = "white",
                    tickfont = list(color = "#555555")),
       camera = list(eye = list(x = 1.5, y = 1.5, z = 1.2)) 
     ),
     paper_bgcolor = "white", 
     plot_bgcolor = "white",
     legend = list(
       title = NULL,
       orientation = "h",  
       x = 0.5,            
       y = -0.1,            
       xanchor = "center",
       font = list(size = 12)
     ),
     margin = list(l = 0, r = 0, b = 50, t = 80) 
   ) 
 
print(fig2)

#Wt vs Wt sirna

Wt_Wtsirna <- slc1a5_data |>
  slice(1:6)
numerical_data3 <- Wt_Wtsirna[,2:23]
numerical_data3 <- scale(numerical_data3)

corr_matrix3 <- cor(numerical_data3)
ggcorrplot(corr_matrix3, 
           hc.order = TRUE,
           type = "lower")

data.pca3 <- prcomp(numerical_data3)
summary(data.pca3) 


fviz_eig(data.pca3, addlabels = TRUE)
data.pca3$rotation[, 1:3]
fviz_pca_var(data.pca3, 
             geom = c("point", "text"),
             col.var = "black",
             repel = TRUE) +
  theme_classic()

fviz_cos2(data.pca3, choice = "var", axes = 1:2)

sample_groups3 <- Wt_Wtsirna[[1]]

pca_3d_data3 <- data.frame(
  PC1 = data.pca3$x[, 1],
  PC2 = data.pca3$x[, 2],
  PC3 = data.pca3$x[, 3],
  Group = sample_groups3
) 

groups3 <- unique(pca_3d_data2$Group)
group_colors <- c("red", "blue")

#dynamic 3D plot 
var_explained3 <- data.pca3$sdev^2 / sum(data.pca3$sdev^2)
pc1_lab3 <- paste0("PC1 (", round(var_explained3[1] * 100, 1), "%)")
pc2_lab3 <- paste0("PC2 (", round(var_explained3[2] * 100, 1), "%)")
pc3_lab3 <- paste0("PC3 (", round(var_explained3[3] * 100, 1), "%)") 


fig3 <- plot_ly(data = pca_3d_data3, 
                x = ~PC1, 
                y = ~PC2, 
                z = ~PC3, 
                color = ~Group, 
                colors = group_colors,
                type = "scatter3d", 
                mode = "markers",
                marker = list(
                  size = 10,                 
                  opacity = 0.9,            
                  line = list(               
                    color = "black",
                    width = 2
                  )
                )) |>
  layout(
    title = list(
      text = "<b>3D PCA</b><br><sup>VEGFR2 WT Vs VEGFR2 WT siRNA SLC1A5</sup>",
      font = list(family = "Helvetica", size = 18, color = "#333333"),
      x = 0.05 
    ),
    scene = list(
      xaxis = list(title = pc1_lab3, 
                   backgroundcolor = "#F4F6F9", 
                   gridcolor = "white", 
                   showbackground = TRUE, 
                   zerolinecolor = "white",
                   tickfont = list(color = "#555555")),
      yaxis = list(title = pc2_lab3, 
                   backgroundcolor = "#F4F6F9", 
                   gridcolor = "white", 
                   showbackground = TRUE, 
                   zerolinecolor = "white",
                   tickfont = list(color = "#555555")),
      zaxis = list(title = pc3_lab3, 
                   backgroundcolor = "#F4F6F9", 
                   gridcolor = "white", 
                   showbackground = TRUE, 
                   zerolinecolor = "white",
                   tickfont = list(color = "#555555")),
      camera = list(eye = list(x = 1.5, y = 1.5, z = 1.2)) 
    ),
    paper_bgcolor = "white", 
    plot_bgcolor = "white",
    legend = list(
      title = NULL,
      orientation = "h",  
      x = 0.5,            
      y = -0.1,            
      xanchor = "center",
      font = list(size = 12)
    ),
    margin = list(l = 0, r = 0, b = 50, t = 80) 
  ) 

print(fig3)


