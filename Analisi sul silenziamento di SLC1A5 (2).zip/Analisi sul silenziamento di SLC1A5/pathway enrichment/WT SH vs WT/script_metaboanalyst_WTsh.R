library(MetaboAnalystR)
library(Cairo)
library(readxl)


#se file trasposto


file_path <- "~/Università/tesi magistrale/dati/metaboloanalyst/SLC1A5/WT_vs_WT_siRNA/MSEA_WT_WTsiRNA.xlsx"
MSEA_data <- read_excel(file_path, sheet = 1) 


numerical_data <- MSEA_data[ , 2:23]
sample_groups <- MSEA_data[[1]]

mets_names <- colnames(numerical_data)
class_labels <- as.character(sample_groups)


sample_names_ma <- paste0("S", 1:nrow(numerical_data))


header <- paste(c("Sample", sample_names_ma), collapse = ",")
labels <- paste(c("Label",  class_labels), collapse = ",")


rows <- apply(cbind(mets_names, as.data.frame(t(numerical_data))), 1, paste, collapse = ",")


output_path <- "~/Università/tesi magistrale/dati/metaboloanalyst/SLC1A5/WT_vs_WT_siRNA/metaboloanalyst_input.csv"
writeLines(c(header, labels, rows), output_path)

# =============================================================================
# STEP 1: MSEA — Over-Representation Analysis (SMPDB)
# =============================================================================

mSet <- InitDataObjects("conc", "msetqea", FALSE, default.dpi = 300)

file_path <- "~/Università/tesi magistrale/dati/metaboloanalyst/SLC1A5/WT_vs_WT_siRNA/metaboloanalyst_input.csv"
mSet <- Read.TextData(mSet, file_path, "colu", "disc")
print(mSet$dataSet$orig)
mSet <- SanityCheckData(mSet)

mSet <- PreparePrenormData(mSet)
mSet <- Normalization(mSet, "NULL", "NULL", "ParetoNorm", ratio=FALSE, ratioNum=20)
mSet <- CrossReferencing(mSet, "name")
mSet <- CreateMappingResultTable(mSet)
mSet <- SetMetabolomeFilter(mSet, FALSE)
mSet <- SetCurrentMsetLib(mSet, "smpdb_pathway", 2)
mSet <- CalculateHyperScore(mSet)


ora_df <- as.data.frame(mSet$analSet$ora.mat)
ora_df$pathway <- rownames(ora_df)
file_path2 <- "~/Università/tesi magistrale/dati/metaboloanalyst/SLC1A5/WT_vs_WT_siRNA/msea_ora_smpdb_results.csv"

write.csv(ora_df, file_path2, row.names = FALSE)

# =============================================================================
# STEP 2: KEGG Pathway Analysis (Topologia)
# =============================================================================
mSet2 <- InitDataObjects("conc", "pathora", FALSE, default.dpi = 300)
mSet2 <- Read.TextData(mSet2, file_path, "colu", "disc")
mSet2 <- SanityCheckData(mSet2)
mSet2 <- PreparePrenormData(mSet2) 


mSet2 <- Normalization(mSet2, "NULL", "LogNorm", "ParetoNorm", ratio=FALSE, ratioNum=20)

mSet2 <- CrossReferencing(mSet2, "name")
mSet2 <- CreateMappingResultTable(mSet2)
mSet2 <- SetKEGG.PathLib(mSet2, "hsa", "current")
mSet2 <- SetMetabolomeFilter(mSet2, F)
mSet2 <- CalculateOraScore(mSet2, "rbc", "hyperg") 


#kegg repository 

kegg_dict <- read.delim("https://rest.kegg.jp/list/pathway/hsa", 
                        header = FALSE, 
                        col.names = c("kegg_id", "pathway_name"),
                        stringsAsFactors = FALSE) 
kegg_dict$kegg_id <- gsub("path:", "", kegg_dict$kegg_id)  
kegg_dict$pathway_name <- gsub(" - Homo sapiens \\(human\\)", "", kegg_dict$pathway_name) 





path_mat <- mSet2$analSet$ora.mat
path_df  <- as.data.frame(path_mat)
colnames(path_df) <- c("total", "expected", "hits", "raw_p", "neg_log10p", "holm_p", "FDR", "impact")
path_df$kegg_id <- rownames(path_df)
match_indices <- match(path_df$kegg_id, kegg_dict$kegg_id)
path_df$pathway_name <- kegg_dict$pathway_name[match_indices]
path_df <- path_df[order(path_df$raw_p), ]
file_path3 <- "~/Università/tesi magistrale/dati/metaboloanalyst/SLC1A5/WT_vs_WT_siRNA/kegg_pathway_results.csv"
write.csv(path_df, file_path3, row.names = FALSE)

# =============================================================================
# STEP 3: Quantitative Enrichment Analysis (QEA — GlobalTest)
# =============================================================================

mSet3 <- InitDataObjects("conc", "msetqea", FALSE, default.dpi = 300)
mSet3 <- Read.TextData(mSet3, file_path, "colu", "disc")
mSet3 <- SanityCheckData(mSet3)
mSet3 <- PreparePrenormData(mSet3)
mSet3 <- Normalization(mSet3, "NULL", "LogNorm", "ParetoNorm", ratio = FALSE, ratioNum = 20)
mSet3 <- CrossReferencing(mSet3, "name")
mSet3 <- CreateMappingResultTable(mSet3)
mSet3 <- SetMetabolomeFilter(mSet3, FALSE)



# Puoi scegliere tra "smpdb_pathway" o "kegg_pathway"
mSet3 <- SetCurrentMsetLib(mSet3, "kegg_pathway", 2) 
mSet3 <- CalculateGlobalTestScore(mSet3) 

file_path4 <- "~/Università/tesi magistrale/dati/metaboloanalyst/SLC1A5/WT_vs_WT_siRNA/qea_results.csv" 

# Estrazione Risultati QEA
qea_mat <- mSet3$analSet$qea.mat
if(!is.null(qea_mat)){
  qea_df  <- as.data.frame(qea_mat)
  qea_df$pathway <- rownames(qea_df)
  col_name <- ifelse("Raw p" %in% colnames(qea_df), "Raw p", "p.value")
  qea_df <- qea_df[order(qea_df[[col_name]]), ]
  print(head(qea_df, 10))
  
  write.csv(qea_df, file_path4, col.names = FALSE )
} 


# =============================================================================
# STEP 4: visualizzazione
# =============================================================================

library(ggplot2)
library(dplyr)
library(ggrepel)

ora_data <- read.csv("~/Università/tesi magistrale/dati/metaboloanalyst/SLC1A5/WT_vs_WT_siRNA/msea_ora_smpdb_results.csv")
kegg_data <- read.csv("~/Università/tesi magistrale/dati/metaboloanalyst/SLC1A5/WT_vs_WT_siRNA/kegg_pathway_results.csv")


#ora data

top_pathways <- ora_data |>
  arrange(Raw.p) |>
  slice_head(n = 15) |>
  mutate(pathway = factor(pathway, levels = rev(pathway))) 

top_pathways |> 
  ggplot(aes(x = -log10(Raw.p), y = pathway))  +
  geom_segment(aes(x = 0, xend = -log10(Raw.p), y = pathway, yend = pathway), color = "grey80") +
  geom_point(aes(size = hits, fill = -log10(Raw.p)), shape = 21, color = "black") +
  scale_fill_gradient(low = "blue", high = "red") +
  scale_size_continuous(range = c(3, 10)) +
  labs(title = "Pathway Enrichment (SMPDB)",
       x = "-Log10 p-value",
       y = NULL,
       size = "Metabolite Count",
       fill = "Significance") +
  theme_minimal() +
  theme(axis.text.y = element_text(size = 10))

#kegg data 
library(ggplot2)
library(dplyr)


kegg_plot_data <- kegg_data |>
  arrange(desc(neg_log10p)) |>
  slice_head(n = 20) |> 
  mutate(pathway_name = factor(pathway_name, levels = rev(pathway_name)))

kegg_plot_data |>
  ggplot( aes(x = impact, y = pathway_name)) +
  geom_vline(xintercept = 0, linetype = "dashed", color = "grey60", alpha = 0.8) +
  geom_point(aes(size = hits, color = neg_log10p), alpha = 0.85) +
  scale_color_gradient(low = "blue", high = "red", 
                       name = expression(-log[10](p))) +
  
  scale_size_continuous(range = c(3, 11), breaks = c(2, 4, 6, 8), name = "Hits") +
  labs(
    title = "KEGG Pathway Analysis",
    subtitle = "VEGFR2 WT siRNA SLC1A5 vs VEGFR2 WT",
    x = "Pathway Impact Score",
    y = NULL
  ) +
  theme_minimal(base_size = 12) +
  theme(
    panel.grid.major.x = element_line(color = "grey90"),
    panel.grid.minor.x = element_blank(),
    panel.grid.major.y = element_blank(), 
    axis.line.x = element_line(color = "black"),
    axis.line.y = element_line(color = "black"),
    axis.text.y = element_text(color = "black", size = 10),
    axis.text.x = element_text(color = "black", size = 10),
    plot.title = element_text(face = "bold", size = 15, hjust = 0.5),
    plot.subtitle = element_text(color = "grey50", size = 11, hjust = 0.5),
    legend.position = "right"
  )


#qea
qea_top <- qea_df |>
  rename(p_val = matches("Raw.p|p.value"),
         fdr_val = matches("FDR")) |>
  arrange(p_val) |>
  slice_head(n = 15) |>
  mutate(pathway = factor(pathway, levels = rev(pathway)),
         log10p = -log10(p_val)) 

qea_top |> 
  ggplot(aes(x = log10p, y = pathway)) +
  geom_segment(aes(x = 0, xend = log10p, y = pathway, yend = pathway), 
               color = "grey80", linewidth = 1) +
  # Punto del "lollipop"
  geom_point(aes(size = `Statistic Q`, fill = fdr_val), 
             shape = 21, color = "black", stroke = 0.5) +
  # Linea di soglia p < 0.05
  geom_vline(xintercept = -log10(0.05), linetype = "dashed", 
             color = "firebrick", alpha = 0.6) +
  # Scala cromatica (FDR basso = colore caldo/evidente)
  scale_fill_gradient(low = "#e31a1c", high = "#feb24c", name = "FDR") +
  scale_size_continuous(range = c(4, 10), name = "Global Statistic") +
  labs(
    title = "Quantitative Enrichment Analysis (GlobalTest)",
    subtitle = "Top 15 Pathways - VEGFR2 WT siRNA SLC1A5 vs VEGFR2 WT",
    x = expression(-log[10](p-value)),
    y = NULL
  ) +
  theme_minimal(base_size = 12) +
  theme(
    panel.grid.minor = element_blank(),
    axis.text.y = element_text(face = "bold", color = "black"),
    plot.title = element_text(face = "bold")
  )